<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>STBI Master</title>
      <link rel="stylesheet" href="css/components.css">
      <link rel="stylesheet" href="css/icons.css">
      <link rel="stylesheet" href="css/responsee.css">
      <link rel="stylesheet" href="owl-carousel/owl.carousel.css">
      <link rel="stylesheet" href="owl-carousel/owl.theme.css"> 
      <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
      <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
      <script type="text/javascript" src="js/jquery-ui.min.js"></script>    
   </head>
   <body class="size-960">
         <!-- TOP NAV -->  
         <div class="line">
            <nav class="margin-bottom">
               <p class="nav-text">Menu</p>
               <div class="top-nav s-12 l-15">
                  <ul>
                     <li><a href="?menu=home">Home</a></li>
                     <li>
                        <a href="?menu=upload">Upload</a>
                     </li>
					 <li>
                        <a href="?menu=carikata">Cari Kata</a>
                     </li>
					 <li>
                        <a href="?menu=query">Cari Query</a>
                     </li>
					 <li>
                        <a href="?menu=hitungbobot">Hitung Bobot</a>
                     </li>
					 <li>
                        <a href="?menu=awalquery">Cari Query 2</a>
                     </li>
					 <li>
                        <a href="?menu=panjangvektor">Hitung Vektor</a>
                     </li>
					 <li>
                        <a href="?menu=download">Download File</a>
                     </li>
               </div>
            </nav>
         </div>
      </header>
      <section>
         <!-- ASIDE NAV AND CONTENT -->
         <div class="line">
            <div class="box margin-bottom">
               <div class="margin">
                  <!-- CONTENT -->
                  <article class="s-12 m-7 l-8">
                  <?php
				error_reporting(0);
				if($_GET[menu]=='')
					{
					include('home.php');
					}
				else
					{
					include($_GET[menu].'.php');
					}
			?>
				  </article>
                  <!-- ASIDE NAV -->
               </div>
            </div>
         </div>
         <!-- GALLERY CAROUSEL -->
      </section>                                                                   
      <script type="text/javascript" src="js/responsee.js"></script>               
      <script type="text/javascript" src="owl-carousel/owl.carousel.js"></script>  
      <script type="text/javascript">
         jQuery(document).ready(function($) {	  
           $("#owl-demo").owlCarousel({		
           	navigation : true,
           	slideSpeed : 300,
           	paginationSpeed : 400,
           	autoPlay : true,
           	singleItem:true
           });
           $("#owl-demo2").owlCarousel({
        		items : 4,
           	lazyLoad : true,
           	autoPlay : true,
           	navigation : true,
           	pagination : false
           });
         });	 
      </script>
   </body>
</html>